"use strict";
var Task = (function () {
    function Task() {
    }
    return Task;
}());
exports.Task = Task;
//# sourceMappingURL=task.js.map